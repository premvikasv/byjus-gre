jQuery(document).ready(function(){

	//Make "contains" case-insensitive
	$.expr[":"].contains = $.expr.createPseudo(function(arg) {
		return function( elem ) {
			return $(elem).text().toUpperCase().indexOf(arg.toUpperCase()) >= 0;
		};
	});

	$("#university").autocomplete({
		source: function(request, response){
			$.ajax({
				url: "http://localhost/SchoolSelector/index.php/Home/getColleges",
				dataType: "json",
				data: request,
				success: function(data){
					if(data.res == true){
						response(data.message);
						$("div.kf_edu2_heading1 .no-match").addClass("invisible");
					}
					else{
						response();
						$("div.kf_edu2_heading1 .no-match").removeClass("invisible");
					}
				}
			});
		}
		// source: "http://localhost/SchoolSelector/index.php/Home/getColleges"
	});
	
	$("#search-college").on("keyup keypress", function(e){
		if($(this).val().length == 0)
			$(".kf_courses_wrap").show();
		if(e.which == 13){
			if($(this).val().length != 0){
				$(".kf_courses_wrap").hide();
				$("div.courses_des_hding1 h5:contains('"+$(this).val()+"')").each(function(){
					$(this).closest(".kf_courses_wrap").show();
				});
			}
			e.preventDefault();
		}
	});
	
	$(".location-col").on("click", function(){
		$(".kf_courses_wrap").hide();
		var loc = $(this).attr("location");
		if(loc == "All")
			$(".kf_courses_wrap").show();
		else
			$(".col-list-details").find("."+loc).show();
	});
	
	// $("form.col-search").submit(function(){
		// event.preventDefault();
		// dataString = $("form.col-search").serialize();
		// $.ajax({
			// type: "POST",
			// url: "http://localhost/SchoolSelector/index.php/Home/readFormElements",
			// data: dataString,
			// dataType: "json",

			// success: function(data){
			   // alert(data);
			// }
         // });
	// });
	
});