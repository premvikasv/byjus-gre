<?php 
							
								if(!empty($colleges)){
								// echo "colleges: ";
									foreach($colleges as $col){
									// echo "col: " . $col->name;
										if(substr( $col->link, 0, 4 ) === "http")
											$col_link = $col->link;
										else
											$col_link = prep_url($col->link);
								
							?>
										<!--kf_courses_wrap Start-->
										<div class="kf_courses_wrap <?= $col->location ?>">
											<div class="row">
												<div class="col-lg-3 col-md-6 col-sm-2">
													<figure class="collogo">
														<?php
														
															$search_query = str_replace( " ", "+", $col->college_name . "+logo+png");
															// $search_query = "University+of+California+Berkeley+logo+png";
															$search_query = urlencode( $search_query );
															$html = file_get_html( "https://www.google.com/search?q=" . $search_query . "&tbm=isch" );
															$images = $html->find('img');
															$image_count = 1; //Enter the amount of images to be shown
															$i = 0;
															foreach($images as $image){
															if($i == $image_count) break;
																$i++;
																// DO with the image whatever you want here (the image element is '$image'):
																$img_src = $image->src;
															}
														
														?>
														<img  src="<?= $img_src ?>" alt="Check your internet connection!"/>
														<a target="_blank" href="<?= $col_link ?>"><i class="fa fa-search"></i></a>
														
													</figure>
												</div>

												<div class="col-lg-8 col-md-5 col-sm-9">
													<!--kf_courses_des Start-->
													<div class="kf_courses_des">
														<div class="courses_des_hding1">
															<h5><?= $col->college_name ?></h5>
														</div>
														<span>Course Price :<small>$69</small></span>

														<p>This is Photoshop's version of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. </p>
														<a href="#">Learn More</a>
													</div>
													<!--kf_courses_des end-->
												</div>
											</div>
										</div>
										<!--kf_courses_wrap end-->
							<?php
							
									}
								}
							
							?>