<?php

	function getAssestsUrl(){
		return "http://localhost/SchoolSelector/assests/";
	}

	function returnEmpty(){
		return " ";
	}
	
	function getHomeUrl(){
		return "http://localhost/SchoolSelector/index.php/";
	}
	
?>