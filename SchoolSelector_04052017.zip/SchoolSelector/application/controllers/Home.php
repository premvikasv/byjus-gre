<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	
	public function index(){
		$this->load->view("homepage");
	}
	
	function getColleges(){
		$this->load->model('model');
		$term = strtolower($_GET['term']);
		$college_names = $this->model->fetchColleges($term);
		if(sizeof($college_names) == 0){
			$data["res"] = false;
		}
		else{
			$data["message"] = array();
			$data["res"] = true;
			foreach($college_names as $col){
				$data["message"][] = $col->name;
			}
		}
		echo json_encode($data);
	}
	
	public function readFormElements(){
		$data["program"] = strtolower($this->input->post("program"));
		$data["courseSpecialization"] = strtolower($this->input->post("courseSpecialization"));
		$data["university"] = strtolower($this->input->post("university"));
		
		if(!empty($data["program"]) || !empty($data["courseSpecialization"]) || !empty($data["university"])){
			$this->load->model("model");
			$data['colleges'] = $this->model->fetchListByCourse($data);
			
			$this->load->view("course-list", $data);
		}
	}
	
	// public function getCollegesByLoc(){
		// $data["location"] = strtolower($this->input->post("loc"));
		
		// $this->load->model("model");
		
	// }
	
}

?>