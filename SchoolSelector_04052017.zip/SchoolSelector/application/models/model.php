<?php

	if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	class Model extends CI_Model{
		public function fetchListByCourse($data){
			if(!empty($data["program"]) && !empty($data["courseSpecialization"]))
				$res = $this->db->query("select *, c.name as college_name from college as c 
									join course as co on c.idcollege = co.college_fk
									join course_specialization as cs on co.idcourse = cs.course_fk
									where co.name = '" . $data['program'] . "' and cs.name = '" . $data['courseSpecialization'] . "'");
			else if(!empty($data["program"]))
				$res = $this->db->query("select *, c.name as college_name from college as c 
									join course as co on c.idcollege = co.college_fk
									join course_specialization as cs on co.idcourse = cs.course_fk
									where co.name = '" . $data['program'] . "'");
			else if(!empty($data["courseSpecialization"]))
				$res = $this->db->query("select *, c.name as college_name from college as c 
									join course as co on c.idcollege = co.college_fk
									join course_specialization as cs on co.idcourse = cs.course_fk
									where cs.name = '" . $data['courseSpecialization'] . "'");
			else
				$res = $this->db->query("select *, c.name as college_name from college as c 
									join course as co on c.idcollege = co.college_fk
									join course_specialization as cs on co.idcourse = cs.course_fk
									where c.name like '" . $data["university"] . "'");
			
			// if($res->num_rows > 0)
				return $res->result();	
			// else
				// return 0;
		}
		
		// public function fetchListByLocation($data){
			// $res = $this->db->query("");
		// }
		
		public function fetchColleges($q){
			// if($res->num_rows > 0){
				// while ($row = $res->result_array()) {
					// $col_names[] = $row['name'];
				// }
				// // echo json_encode($col_names);
			// }
				// return $res->result();
			
			// $this->db->select('name');
			// $this->db->like('name', $q);
			// $query = $this->db->get('college');
			$query = $this->db->query("select name from college where name like '%". $q ."%'");
			// while($row = $query->result_array()){
				// $col_names[] = $row['name'];
			// }
			return $query->result();
		}
	}

?>